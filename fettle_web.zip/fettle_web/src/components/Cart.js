
import { CartContext } from "./CartContext";




export function Cart() {
  return (
    <> 
     <CartContext/>
    </>
  );
}
