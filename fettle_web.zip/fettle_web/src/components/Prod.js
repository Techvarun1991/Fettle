import React from 'react';


export const Prod =[
    {
        "id": 1,
        "url" : require('./Images/20L.webp'),
        "Capacity": "20 L Drinking Water",
        "Price": 60,
        "qnty": 0
    },
    {
        "id": 2,
        "url" : require('./Images/10L.webp'),
        "Capacity": "10 L Drinking Water", 
        "Price": 40,
        "qnty": 0
    },
    {
        "id": 3,
        "url" : require('./Images/5L.jpg'),
        "Capacity": "5L Drinking Water",
        "Price": 30,
        "qnty": 0
    },
    {
        "id": 4,
        "url" : require('./Images/2L.jpg'),
        "Capacity": "2L Drinking Water",
        "Price": 25,
        "qnty": 0
    },
    {
        "id": 5,
        "url" : require('./Images/1L.png'),
        "Capacity": "1L Drinking Water",
        "Price": 15,
        "qnty": 0
    },
    {
        "id": 6,
        "url" : require('./Images/500ml.jpg'),
        "Capacity": "500 ml Drinking Water",
        "Price": 10,
        "qnty": 0
    },
    {
        "id": 7,
        "url" : require('./Images/250ML.jpeg'),
        "Capacity": "250 ml Drinking Water",
        "Price": 5,
        "qnty": 0
    }

]

